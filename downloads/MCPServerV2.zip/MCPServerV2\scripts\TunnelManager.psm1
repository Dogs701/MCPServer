Set-StrictMode -Version Latest

function Ensure-TunnelProvider {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$RootPath,
        [Parameter(Mandatory)][string]$ServerPath,
        [Parameter(Mandatory)][string]$MinecraftVersion,
        [Parameter(Mandatory)][bool]$Enabled,
        [Parameter(Mandatory)][string]$LauncherLogPath
    )

    if (-not $Enabled) {
        return [pscustomobject]@{
            Enabled      = $false
            ProviderName = 'Disabled'
        }
    }

    $pluginsPath = Join-Path $ServerPath 'plugins'
    $pluginPath = Join-Path $pluginsPath 'playit-companion.jar'
    $infoPath = Join-Path $RootPath 'tunnel\README.txt'
    $apiUrl = "https://api.modrinth.com/v2/project/playit-companion/version?loaders=%5B%22paper%22%5D&game_versions=%5B%22$MinecraftVersion%22%5D&featured=true&include_changelog=false"

    Write-Info 'Preparing no-port-forwarding tunnel helper...'

    if (-not (Test-Path -LiteralPath $pluginsPath)) {
        New-Item -ItemType Directory -Path $pluginsPath -Force | Out-Null
    }

    try {
        $versions = Invoke-RestMethod -Uri $apiUrl -Headers @{ 'User-Agent' = 'MCPServer/1.0.0 (https://example.com/mcpserver)' }
        $version = $versions | Select-Object -First 1
    }
    catch {
        Write-Warn 'Tunnel helper could not be downloaded right now. The server can still run locally.'
        Write-LogLine -Path $LauncherLogPath -Message ("Tunnel provider download lookup failed: " + $_.Exception.Message)
        return [pscustomobject]@{
            Enabled      = $false
            ProviderName = 'Unavailable'
        }
    }

    if (-not $version) {
        Write-Warn "No Playit Companion build was found for Minecraft $MinecraftVersion."
        return [pscustomobject]@{
            Enabled      = $false
            ProviderName = 'Unavailable'
        }
    }

    $primaryFile = $version.files | Where-Object { $_.primary } | Select-Object -First 1
    if (-not $primaryFile) {
        $primaryFile = $version.files | Select-Object -First 1
    }

    if (-not $primaryFile.url) {
        Write-Warn 'Tunnel helper download URL was missing.'
        return [pscustomobject]@{
            Enabled      = $false
            ProviderName = 'Unavailable'
        }
    }

    if (-not (Test-Path -LiteralPath $pluginPath)) {
        try {
            Invoke-WebRequest -Uri $primaryFile.url -Headers @{ 'User-Agent' = 'MCPServer/1.0.0 (https://example.com/mcpserver)' } -OutFile $pluginPath
            Write-Success 'Tunnel helper installed.'
            Write-LogLine -Path $LauncherLogPath -Message "Downloaded tunnel helper from $($primaryFile.url)"
        }
        catch {
            Write-Warn 'Tunnel helper download failed. The server can still run locally.'
            Write-LogLine -Path $LauncherLogPath -Message ("Tunnel helper download failed: " + $_.Exception.Message)
            return [pscustomobject]@{
                Enabled      = $false
                ProviderName = 'Unavailable'
            }
        }
    }
    else {
        Write-Success 'Tunnel helper already installed.'
    }

    Set-Content -LiteralPath $infoPath -Value @(
        'MCPServer uses Playit Companion for the public join address.'
        'This avoids port forwarding and gives players a friendly hostname.'
        ''
        'Important: the very first run may ask you to claim the tunnel in a browser.'
        'After that, the plugin can print a claim link or a public hostname in the server output.'
    )

    return [pscustomobject]@{
        Enabled      = $true
        ProviderName = 'Playit Companion'
    }
}

function Find-TunnelHints {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$Line
    )

    if ($Line -match 'https://playit\.gg/claim/[A-Za-z0-9]+') {
        Write-Host ''
        Write-Host '============================================================' -ForegroundColor Magenta
        Write-Host 'Tunnel Claim Link Found' -ForegroundColor Magenta
        Write-Host 'Open this link once to connect the tunnel to your account:' -ForegroundColor Magenta
        Write-Host $Matches[0] -ForegroundColor White
        Write-Host '============================================================' -ForegroundColor Magenta
        Write-Host ''
        return
    }

    if ($Line -match '\b[a-zA-Z0-9.-]+\.(ply\.gg|playit\.gg|playit\.plus)\b') {
        Write-Host ''
        Write-Host '============================================================' -ForegroundColor Green
        Write-Host 'Public Join Address' -ForegroundColor Green
        Write-Host $Matches[0] -ForegroundColor White
        Write-Host 'Share that address with your friends in Minecraft Java Edition.' -ForegroundColor Green
        Write-Host '============================================================' -ForegroundColor Green
        Write-Host ''
    }
}

Export-ModuleMember -Function *-*
