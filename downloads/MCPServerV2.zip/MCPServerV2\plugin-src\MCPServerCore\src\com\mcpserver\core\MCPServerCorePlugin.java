package com.mcpserver.core;

import com.mcpserver.core.mcp.api.BukkitPluginApi;
import com.mcpserver.core.mcp.runtime.McpPluginManager;
import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.java.JavaPlugin;

public final class MCPServerCorePlugin extends JavaPlugin implements Listener {
    private UUID ownerUuid;
    private McpPluginManager mcpPluginManager;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadOwnerFromConfig();

        File pluginsRoot = getDataFolder().getParentFile();
        File mcpPluginsFolder = new File(pluginsRoot, "MCPPlugins");
        this.mcpPluginManager = new McpPluginManager(this, mcpPluginsFolder);

        Bukkit.getPluginManager().registerEvents(this, this);

        try {
            mcpPluginManager.loadPlugins();
        } catch (IOException ex) {
            getLogger().severe("Failed to load MCP plugins: " + ex.getMessage());
        }

        getLogger().info("MCPServer core plugin host enabled.");
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();

        if (ownerUuid == null) {
            ownerUuid = player.getUniqueId();
            player.setOp(true);
            saveOwner(player);
            player.sendMessage(colorize("&6&lMCPServer &8> &aYou are now the server owner and have been given OP."));
        }

        Bukkit.getScheduler().runTaskLater(this, () -> {
            player.sendMessage(colorize("&6&lWelcome to your brand new &b&lMCPServer&6&l!"));
            player.sendMessage(colorize("&dWe are working toward improving this software more."));
            player.sendMessage(colorize("&aWe would love your feedback. Thanks for testing it!"));
        }, 20L);

        if (mcpPluginManager != null) {
            mcpPluginManager.emit("player.join", Map.of(
                    "player", player.getName(),
                    "uuid", player.getUniqueId().toString()));
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onPlayerCommandPreprocess(PlayerCommandPreprocessEvent event) {
        if (mcpPluginManager == null) {
            return;
        }

        String message = event.getMessage();
        if (message == null || message.isBlank() || !message.startsWith("/")) {
            return;
        }

        String raw = message.substring(1);
        String[] parts = raw.split("\\s+");
        if (parts.length == 0 || parts[0].isBlank()) {
            return;
        }

        boolean handled = mcpPluginManager.dispatchCommand(parts[0], Map.of(
                "sender", event.getPlayer().getName(),
                "message", message));
        if (handled) {
            event.setCancelled(true);
        }
    }

    @Override
    public void onDisable() {
        if (mcpPluginManager != null) {
            mcpPluginManager.clear();
        }
    }

    public BukkitPluginApi createPluginApi() {
        return new BukkitPluginApi(this);
    }

    public String colorize(String message) {
        return ChatColor.translateAlternateColorCodes('&', message);
    }

    private void loadOwnerFromConfig() {
        FileConfiguration config = getConfig();
        String ownerUuidText = config.getString("owner.uuid", "");

        if (!ownerUuidText.isBlank()) {
            ownerUuid = UUID.fromString(ownerUuidText);
        }
    }

    private void saveOwner(Player player) {
        FileConfiguration config = getConfig();
        config.set("owner.uuid", player.getUniqueId().toString());
        config.set("owner.name", player.getName());
        saveConfig();
    }
}
