Set-StrictMode -Version Latest

function Get-ServerPidFilePath {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$ServerPath
    )

    return (Join-Path $ServerPath 'mcpserver.pid')
}

function Set-ServerPidFile {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$ServerPath,
        [Parameter(Mandatory)][int]$ProcessId
    )

    Set-Content -LiteralPath (Get-ServerPidFilePath -ServerPath $ServerPath) -Value $ProcessId
}

function Clear-ServerPidFile {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$ServerPath
    )

    $pidPath = Get-ServerPidFilePath -ServerPath $ServerPath
    if (Test-Path -LiteralPath $pidPath) {
        Remove-Item -LiteralPath $pidPath -Force
    }
}

function Get-RunningServerProcess {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$ServerPath,
        [Parameter(Mandatory)][string]$ServerJarPath
    )

    $pidPath = Get-ServerPidFilePath -ServerPath $ServerPath
    if (Test-Path -LiteralPath $pidPath) {
        $pidText = (Get-Content -LiteralPath $pidPath -ErrorAction SilentlyContinue | Select-Object -First 1)
        if ($pidText -match '^\d+$') {
            $candidatePid = [int]$pidText
            $process = Get-CimInstance Win32_Process -Filter "ProcessId = $candidatePid" -ErrorAction SilentlyContinue
            if ($process) {
                return $process
            }
        }

        Clear-ServerPidFile -ServerPath $ServerPath
    }

    return $null
}

function Write-HostJoinGuide {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$ServerPath
    )

    $joinGuidePath = Join-Path $ServerPath 'HOST-JOIN.txt'
    Set-Content -LiteralPath $joinGuidePath -Value @(
        'If you are playing on the same computer as the server, use:'
        'localhost'
        ''
        'If your friends are joining from somewhere else, use the public Playit address.'
    )
}

function Write-PublicJoinAddressFiles {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$ServerPath,
        [Parameter(Mandatory)][string]$JoinAddress
    )

    $rootPath = Split-Path -Parent $ServerPath
    if ((Split-Path -Leaf $ServerPath) -eq 'server') {
        $rootPath = Split-Path -Parent $ServerPath
    }
    elseif ((Split-Path -Leaf (Split-Path -Parent $ServerPath)) -eq 'instances') {
        $rootPath = Split-Path -Parent (Split-Path -Parent $ServerPath)
    }

    $serverJoinPath = Join-Path $ServerPath 'JOIN-ADDRESS.txt'
    $rootJoinPath = Join-Path $rootPath 'JOIN-ADDRESS.txt'

    $content = @(
        'MCPServer Public Join Address'
        '============================'
        ''
        "Friends should use: $JoinAddress"
        'If you are playing on the same computer as the server, use: localhost'
    )

    Set-Content -LiteralPath $serverJoinPath -Value $content
    Set-Content -LiteralPath $rootJoinPath -Value $content
}

function Get-ServerLogPath {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$ServerPath
    )

    return (Join-Path $ServerPath 'logs\latest.log')
}

function Show-PublicJoinAddress {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$ServerPath,
        [Parameter(Mandatory)][string]$JoinAddress
    )

    Write-PublicJoinAddressFiles -ServerPath $ServerPath -JoinAddress $JoinAddress
    Write-Host ''
    Write-Host '============================================================' -ForegroundColor Green
    Write-Host 'Public Join Address' -ForegroundColor Green
    Write-Host $JoinAddress -ForegroundColor White
    Write-Host 'Share that address with your friends in Minecraft Java Edition.' -ForegroundColor Green
    Write-Host "Saved to: $(Join-Path $ServerPath 'JOIN-ADDRESS.txt')" -ForegroundColor Green
    Write-Host '============================================================' -ForegroundColor Green
    Write-Host ''
}

function Show-TunnelClaimLink {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$ClaimLink
    )

    Write-Host ''
    Write-Host '============================================================' -ForegroundColor Magenta
    Write-Host 'Tunnel Claim Link Found' -ForegroundColor Magenta
    Write-Host 'Open this link once to connect the tunnel to your account:' -ForegroundColor Magenta
    Write-Host $ClaimLink -ForegroundColor White
    Write-Host '============================================================' -ForegroundColor Magenta
    Write-Host ''
}

function Get-TunnelLogHints {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$ServerPath
    )

    $logPath = Get-ServerLogPath -ServerPath $ServerPath
    if (-not (Test-Path -LiteralPath $logPath)) {
        return $null
    }

    $logLines = Get-Content -LiteralPath $logPath -Tail 80 -ErrorAction SilentlyContinue
    if (-not $logLines) {
        return $null
    }

    $claimLink = $null
    $joinAddress = $null

    foreach ($line in $logLines) {
        if (-not $claimLink -and $line -match 'https://playit\.gg/claim/[A-Za-z0-9]+') {
            $claimLink = $Matches[0]
        }

        if (-not $joinAddress -and $line -match 'Server available at (?<address>[a-zA-Z0-9.-]+\.(ply\.gg|playit\.gg|playit\.plus|joinmc\.link))') {
            $joinAddress = $Matches.address
        }
        elseif (-not $joinAddress -and $line -match '\b(?<address>[a-zA-Z0-9.-]+\.(ply\.gg|playit\.gg|playit\.plus|joinmc\.link))\b') {
            $joinAddress = $Matches.address
        }
    }

    return [pscustomobject]@{
        ClaimLink   = $claimLink
        JoinAddress = $joinAddress
    }
}

function Stop-McpServerProcesses {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$RootPath,
        [Parameter(Mandatory)][string]$LauncherLogPath
    )

    $processes = @()

    $listeners = Get-NetTCPConnection -LocalPort 25565 -State Listen -ErrorAction SilentlyContinue
    if ($listeners) {
        foreach ($listener in $listeners) {
            $process = Get-Process -Id $listener.OwningProcess -ErrorAction SilentlyContinue
            if ($process -and $process.ProcessName -match '^javaw?$') {
                $processes += $process
            }
        }
    }

    if (-not $processes) {
        $processes = Get-Process java,javaw -ErrorAction SilentlyContinue | Where-Object {
            $_.Path -and $_.Path -like '*java.exe'
        }
    }

    if (-not $processes) {
        Write-Warn 'No running MCPServer Java server was found for this folder.'
    }
    else {
        foreach ($process in $processes) {
            Write-Info "Stopping running MCPServer Java process: $($process.Id)"
            Stop-Process -Id $process.Id -Force -ErrorAction SilentlyContinue
            Write-LogLine -Path $LauncherLogPath -Message "Stopped MCPServer Java process $($process.Id)"
        }

        Write-Success 'Running MCPServer server process stopped.'
    }

    Get-ChildItem -Path $RootPath -Recurse -Filter 'mcpserver.pid' -File -ErrorAction SilentlyContinue |
        Remove-Item -Force -ErrorAction SilentlyContinue
}

function Ensure-PaperServer {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$RootPath,
        [Parameter(Mandatory)][string]$ServerPath,
        [Parameter(Mandatory)][string]$MinecraftVersion,
        [Parameter(Mandatory)][string]$PaperProject,
        [Parameter(Mandatory)][string]$LauncherLogPath
    )

    if (-not (Test-Path -LiteralPath $ServerPath)) {
        New-Item -ItemType Directory -Path $ServerPath -Force | Out-Null
    }

    $serverJarPath = Join-Path $ServerPath 'paper.jar'

    if (Test-Path -LiteralPath $serverJarPath) {
        Write-Success 'Paper server already exists. Skipping download.'
        return [pscustomobject]@{
            ServerJarPath     = $serverJarPath
            MinecraftVersion  = $MinecraftVersion
        }
    }

    Write-Info 'Checking for the latest stable Paper build...'
    $userAgent = 'MCPServer/1.0.0 (https://example.com/mcpserver)'
    $buildsUri = "https://fill.papermc.io/v3/projects/$PaperProject/versions/$MinecraftVersion/builds"

    try {
        $builds = Invoke-RestMethod -Uri $buildsUri -Headers @{ 'User-Agent' = $userAgent }
    }
    catch {
        throw "Paper download lookup failed. Please check your internet connection. $($_.Exception.Message)"
    }

    $stableBuild = $builds | Where-Object { $_.channel -eq 'STABLE' } | Select-Object -First 1
    if (-not $stableBuild) {
        throw "No stable Paper build was found for Minecraft $MinecraftVersion."
    }

    $downloadUrl = $stableBuild.downloads.'server:default'.url
    if (-not $downloadUrl) {
        throw 'Paper returned a build, but no server download URL was included.'
    }

    Write-Info "Downloading Paper for Minecraft $MinecraftVersion..."
    Write-LogLine -Path $LauncherLogPath -Message "Downloading Paper from $downloadUrl"

    try {
        Invoke-WebRequest -Uri $downloadUrl -Headers @{ 'User-Agent' = $userAgent } -OutFile $serverJarPath
    }
    catch {
        throw "Paper download failed. $($_.Exception.Message)"
    }

    Write-Success 'Paper server downloaded.'

    return [pscustomobject]@{
        ServerJarPath     = $serverJarPath
        MinecraftVersion  = $MinecraftVersion
    }
}

function Initialize-ServerFiles {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$ServerPath,
        [Parameter(Mandatory)][string]$ServerJarPath,
        [Parameter(Mandatory)][string]$MinecraftVersion,
        [Parameter(Mandatory)][string]$LauncherLogPath
    )

    if (-not (Test-Path -LiteralPath $ServerPath)) {
        New-Item -ItemType Directory -Path $ServerPath -Force | Out-Null
    }

    $eulaPath = Join-Path $ServerPath 'eula.txt'
    $readmePath = Join-Path $ServerPath 'README-FIRST.txt'

    Set-Content -LiteralPath $eulaPath -Value @(
        '# MCPServer accepted this automatically for the local host.'
        '# Mojang EULA: https://aka.ms/MinecraftEULA'
        'eula=true'
    )

    Set-Content -LiteralPath $readmePath -Value @(
        'MCPServer created this Paper server folder automatically.'
        "Minecraft version: $MinecraftVersion"
        "Server jar: $(Split-Path -Leaf $ServerJarPath)"
        ''
        'You usually only need to run start.bat from the main MCPServer folder.'
    )

    Write-LogLine -Path $LauncherLogPath -Message 'Server files initialized and EULA accepted.'
    Write-Success 'Server folder is ready.'
}

function Test-PortAvailable {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [int]$Port
    )

    $listener = Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue
    return -not [bool]$listener
}

function Ensure-McpServerPlugin {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$RootPath,
        [Parameter(Mandatory)][string]$ServerPath,
        [Parameter(Mandatory)][string]$MinecraftVersion,
        [Parameter(Mandatory)][int]$RequiredJavaMajor,
        [Parameter(Mandatory)][string]$JavaPath,
        [Parameter(Mandatory)][string]$ServerJarPath,
        [Parameter(Mandatory)][string]$LauncherLogPath
    )

    $javaBinPath = Split-Path -Parent $JavaPath
    $javacPath = Join-Path $javaBinPath 'javac.exe'
    $jarPath = Join-Path $javaBinPath 'jar.exe'
    $pluginSourceRoot = Join-Path $RootPath 'plugin-src\MCPServerCore'
    $sourcePath = Join-Path $pluginSourceRoot 'src'
    $vendorPath = Join-Path $pluginSourceRoot 'vendor'
    $buildRoot = Join-Path $pluginSourceRoot 'build'
    $classesPath = Join-Path $buildRoot 'classes'
    $compileLibPath = Join-Path $buildRoot 'compile-lib'
    $pluginOutputPath = Join-Path $ServerPath 'plugins\mcpserver-core.jar'
    $libraryRoot = Join-Path $ServerPath 'libraries'
    $compileDependencyJars = Get-ChildItem -LiteralPath $libraryRoot -Recurse -Include *.jar -File -ErrorAction SilentlyContinue

    if (-not (Test-Path -LiteralPath (Join-Path $ServerPath 'plugins'))) {
        New-Item -ItemType Directory -Path (Join-Path $ServerPath 'plugins') -Force | Out-Null
    }

    if (-not (Test-Path -LiteralPath $javacPath)) {
        throw 'Java was found, but javac.exe was not available. Please install a full JDK, not a JRE.'
    }

    if (-not (Test-Path -LiteralPath $jarPath)) {
        throw 'Java was found, but jar.exe was not available. Please install a full JDK, not a JRE.'
    }

    if (-not $compileDependencyJars) {
        Write-Warn 'MCPServer custom plugin host will be built after the first full server startup, once Paper finishes downloading its libraries.'
        Write-LogLine -Path $LauncherLogPath -Message 'Skipped MCPServer plugin build because Paper libraries are not ready yet.'
        return
    }

    $sourceFiles = Get-ChildItem -LiteralPath $sourcePath -Recurse -Filter *.java -File
    $vendorJars = if (Test-Path -LiteralPath $vendorPath) { Get-ChildItem -LiteralPath $vendorPath -Filter *.jar -File } else { @() }
    if (-not $sourceFiles) {
        throw "MCPServer plugin source files were not found in $sourcePath"
    }

    $newestSourceWrite = ($sourceFiles | Sort-Object LastWriteTimeUtc -Descending | Select-Object -First 1).LastWriteTimeUtc
    if ($vendorJars) {
        $newestVendorWrite = ($vendorJars | Sort-Object LastWriteTimeUtc -Descending | Select-Object -First 1).LastWriteTimeUtc
        if ($newestVendorWrite -gt $newestSourceWrite) {
            $newestSourceWrite = $newestVendorWrite
        }
    }
    $pluginNeedsBuild = $true

    if (Test-Path -LiteralPath $pluginOutputPath) {
        $pluginWrite = (Get-Item -LiteralPath $pluginOutputPath).LastWriteTimeUtc
        $pluginNeedsBuild = $pluginWrite -lt $newestSourceWrite
    }

    if (-not $pluginNeedsBuild) {
        Write-Success 'MCPServer plugin host already built.'
        return
    }

    Write-Info "Building MCPServer plugin host for Minecraft $MinecraftVersion on Java $RequiredJavaMajor..."
    Write-LogLine -Path $LauncherLogPath -Message "Building MCPServer plugin for Minecraft $MinecraftVersion with Java $RequiredJavaMajor."

    if (Test-Path -LiteralPath $buildRoot) {
        Remove-Item -LiteralPath $buildRoot -Recurse -Force
    }

    New-Item -ItemType Directory -Path $classesPath -Force | Out-Null
    New-Item -ItemType Directory -Path $compileLibPath -Force | Out-Null

    foreach ($dependencyJar in $compileDependencyJars) {
        Copy-Item -LiteralPath $dependencyJar.FullName -Destination (Join-Path $compileLibPath $dependencyJar.Name) -Force
    }

    $javaSourceList = $sourceFiles | ForEach-Object { Set-StrictMode -Version Latest

function Get-ServerPidFilePath {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$ServerPath
    )

    return (Join-Path $ServerPath 'mcpserver.pid')
}

function Set-ServerPidFile {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$ServerPath,
        [Parameter(Mandatory)][int]$ProcessId
    )

    Set-Content -LiteralPath (Get-ServerPidFilePath -ServerPath $ServerPath) -Value $ProcessId
}

function Clear-ServerPidFile {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$ServerPath
    )

    $pidPath = Get-ServerPidFilePath -ServerPath $ServerPath
    if (Test-Path -LiteralPath $pidPath) {
        Remove-Item -LiteralPath $pidPath -Force
    }
}

function Get-RunningServerProcess {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$ServerPath,
        [Parameter(Mandatory)][string]$ServerJarPath
    )

    $pidPath = Get-ServerPidFilePath -ServerPath $ServerPath
    if (Test-Path -LiteralPath $pidPath) {
        $pidText = (Get-Content -LiteralPath $pidPath -ErrorAction SilentlyContinue | Select-Object -First 1)
        if ($pidText -match '^\d+$') {
            $candidatePid = [int]$pidText
            $process = Get-CimInstance Win32_Process -Filter "ProcessId = $candidatePid" -ErrorAction SilentlyContinue
            if ($process) {
                return $process
            }
        }

        Clear-ServerPidFile -ServerPath $ServerPath
    }

    return $null
}

function Write-HostJoinGuide {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$ServerPath
    )

    $joinGuidePath = Join-Path $ServerPath 'HOST-JOIN.txt'
    Set-Content -LiteralPath $joinGuidePath -Value @(
        'If you are playing on the same computer as the server, use:'
        'localhost'
        ''
        'If your friends are joining from somewhere else, use the public Playit address.'
    )
}

function Write-PublicJoinAddressFiles {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$ServerPath,
        [Parameter(Mandatory)][string]$JoinAddress
    )

    $rootPath = Split-Path -Parent $ServerPath
    if ((Split-Path -Leaf $ServerPath) -eq 'server') {
        $rootPath = Split-Path -Parent $ServerPath
    }
    elseif ((Split-Path -Leaf (Split-Path -Parent $ServerPath)) -eq 'instances') {
        $rootPath = Split-Path -Parent (Split-Path -Parent $ServerPath)
    }

    $serverJoinPath = Join-Path $ServerPath 'JOIN-ADDRESS.txt'
    $rootJoinPath = Join-Path $rootPath 'JOIN-ADDRESS.txt'

    $content = @(
        'MCPServer Public Join Address'
        '============================'
        ''
        "Friends should use: $JoinAddress"
        'If you are playing on the same computer as the server, use: localhost'
    )

    Set-Content -LiteralPath $serverJoinPath -Value $content
    Set-Content -LiteralPath $rootJoinPath -Value $content
}

function Get-ServerLogPath {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$ServerPath
    )

    return (Join-Path $ServerPath 'logs\latest.log')
}

function Show-PublicJoinAddress {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$ServerPath,
        [Parameter(Mandatory)][string]$JoinAddress
    )

    Write-PublicJoinAddressFiles -ServerPath $ServerPath -JoinAddress $JoinAddress
    Write-Host ''
    Write-Host '============================================================' -ForegroundColor Green
    Write-Host 'Public Join Address' -ForegroundColor Green
    Write-Host $JoinAddress -ForegroundColor White
    Write-Host 'Share that address with your friends in Minecraft Java Edition.' -ForegroundColor Green
    Write-Host "Saved to: $(Join-Path $ServerPath 'JOIN-ADDRESS.txt')" -ForegroundColor Green
    Write-Host '============================================================' -ForegroundColor Green
    Write-Host ''
}

function Show-TunnelClaimLink {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$ClaimLink
    )

    Write-Host ''
    Write-Host '============================================================' -ForegroundColor Magenta
    Write-Host 'Tunnel Claim Link Found' -ForegroundColor Magenta
    Write-Host 'Open this link once to connect the tunnel to your account:' -ForegroundColor Magenta
    Write-Host $ClaimLink -ForegroundColor White
    Write-Host '============================================================' -ForegroundColor Magenta
    Write-Host ''
}

function Get-TunnelLogHints {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$ServerPath
    )

    $logPath = Get-ServerLogPath -ServerPath $ServerPath
    if (-not (Test-Path -LiteralPath $logPath)) {
        return $null
    }

    $logLines = Get-Content -LiteralPath $logPath -Tail 80 -ErrorAction SilentlyContinue
    if (-not $logLines) {
        return $null
    }

    $claimLink = $null
    $joinAddress = $null

    foreach ($line in $logLines) {
        if (-not $claimLink -and $line -match 'https://playit\.gg/claim/[A-Za-z0-9]+') {
            $claimLink = $Matches[0]
        }

        if (-not $joinAddress -and $line -match 'Server available at (?<address>[a-zA-Z0-9.-]+\.(ply\.gg|playit\.gg|playit\.plus|joinmc\.link))') {
            $joinAddress = $Matches.address
        }
        elseif (-not $joinAddress -and $line -match '\b(?<address>[a-zA-Z0-9.-]+\.(ply\.gg|playit\.gg|playit\.plus|joinmc\.link))\b') {
            $joinAddress = $Matches.address
        }
    }

    return [pscustomobject]@{
        ClaimLink   = $claimLink
        JoinAddress = $joinAddress
    }
}

function Stop-McpServerProcesses {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$RootPath,
        [Parameter(Mandatory)][string]$LauncherLogPath
    )

    $processes = @()

    $listeners = Get-NetTCPConnection -LocalPort 25565 -State Listen -ErrorAction SilentlyContinue
    if ($listeners) {
        foreach ($listener in $listeners) {
            $process = Get-Process -Id $listener.OwningProcess -ErrorAction SilentlyContinue
            if ($process -and $process.ProcessName -match '^javaw?$') {
                $processes += $process
            }
        }
    }

    if (-not $processes) {
        $processes = Get-Process java,javaw -ErrorAction SilentlyContinue | Where-Object {
            $_.Path -and $_.Path -like '*java.exe'
        }
    }

    if (-not $processes) {
        Write-Warn 'No running MCPServer Java server was found for this folder.'
    }
    else {
        foreach ($process in $processes) {
            Write-Info "Stopping running MCPServer Java process: $($process.Id)"
            Stop-Process -Id $process.Id -Force -ErrorAction SilentlyContinue
            Write-LogLine -Path $LauncherLogPath -Message "Stopped MCPServer Java process $($process.Id)"
        }

        Write-Success 'Running MCPServer server process stopped.'
    }

    Get-ChildItem -Path $RootPath -Recurse -Filter 'mcpserver.pid' -File -ErrorAction SilentlyContinue |
        Remove-Item -Force -ErrorAction SilentlyContinue
}

function Ensure-PaperServer {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$RootPath,
        [Parameter(Mandatory)][string]$ServerPath,
        [Parameter(Mandatory)][string]$MinecraftVersion,
        [Parameter(Mandatory)][string]$PaperProject,
        [Parameter(Mandatory)][string]$LauncherLogPath
    )

    if (-not (Test-Path -LiteralPath $ServerPath)) {
        New-Item -ItemType Directory -Path $ServerPath -Force | Out-Null
    }

    $serverJarPath = Join-Path $ServerPath 'paper.jar'

    if (Test-Path -LiteralPath $serverJarPath) {
        Write-Success 'Paper server already exists. Skipping download.'
        return [pscustomobject]@{
            ServerJarPath     = $serverJarPath
            MinecraftVersion  = $MinecraftVersion
        }
    }

    Write-Info 'Checking for the latest stable Paper build...'
    $userAgent = 'MCPServer/1.0.0 (https://example.com/mcpserver)'
    $buildsUri = "https://fill.papermc.io/v3/projects/$PaperProject/versions/$MinecraftVersion/builds"

    try {
        $builds = Invoke-RestMethod -Uri $buildsUri -Headers @{ 'User-Agent' = $userAgent }
    }
    catch {
        throw "Paper download lookup failed. Please check your internet connection. $($_.Exception.Message)"
    }

    $stableBuild = $builds | Where-Object { $_.channel -eq 'STABLE' } | Select-Object -First 1
    if (-not $stableBuild) {
        throw "No stable Paper build was found for Minecraft $MinecraftVersion."
    }

    $downloadUrl = $stableBuild.downloads.'server:default'.url
    if (-not $downloadUrl) {
        throw 'Paper returned a build, but no server download URL was included.'
    }

    Write-Info "Downloading Paper for Minecraft $MinecraftVersion..."
    Write-LogLine -Path $LauncherLogPath -Message "Downloading Paper from $downloadUrl"

    try {
        Invoke-WebRequest -Uri $downloadUrl -Headers @{ 'User-Agent' = $userAgent } -OutFile $serverJarPath
    }
    catch {
        throw "Paper download failed. $($_.Exception.Message)"
    }

    Write-Success 'Paper server downloaded.'

    return [pscustomobject]@{
        ServerJarPath     = $serverJarPath
        MinecraftVersion  = $MinecraftVersion
    }
}

function Initialize-ServerFiles {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$ServerPath,
        [Parameter(Mandatory)][string]$ServerJarPath,
        [Parameter(Mandatory)][string]$MinecraftVersion,
        [Parameter(Mandatory)][string]$LauncherLogPath
    )

    if (-not (Test-Path -LiteralPath $ServerPath)) {
        New-Item -ItemType Directory -Path $ServerPath -Force | Out-Null
    }

    $eulaPath = Join-Path $ServerPath 'eula.txt'
    $readmePath = Join-Path $ServerPath 'README-FIRST.txt'

    Set-Content -LiteralPath $eulaPath -Value @(
        '# MCPServer accepted this automatically for the local host.'
        '# Mojang EULA: https://aka.ms/MinecraftEULA'
        'eula=true'
    )

    Set-Content -LiteralPath $readmePath -Value @(
        'MCPServer created this Paper server folder automatically.'
        "Minecraft version: $MinecraftVersion"
        "Server jar: $(Split-Path -Leaf $ServerJarPath)"
        ''
        'You usually only need to run start.bat from the main MCPServer folder.'
    )

    Write-LogLine -Path $LauncherLogPath -Message 'Server files initialized and EULA accepted.'
    Write-Success 'Server folder is ready.'
}

function Test-PortAvailable {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [int]$Port
    )

    $listener = Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue
    return -not [bool]$listener
}

function Ensure-McpServerPlugin {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$RootPath,
        [Parameter(Mandatory)][string]$ServerPath,
        [Parameter(Mandatory)][string]$MinecraftVersion,
        [Parameter(Mandatory)][int]$RequiredJavaMajor,
        [Parameter(Mandatory)][string]$JavaPath,
        [Parameter(Mandatory)][string]$ServerJarPath,
        [Parameter(Mandatory)][string]$LauncherLogPath
    )

    $javaBinPath = Split-Path -Parent $JavaPath
    $javacPath = Join-Path $javaBinPath 'javac.exe'
    $jarPath = Join-Path $javaBinPath 'jar.exe'
    $pluginSourceRoot = Join-Path $RootPath 'plugin-src\MCPServerCore'
    $sourcePath = Join-Path $pluginSourceRoot 'src'
    $resourcePath = Join-Path $pluginSourceRoot 'resources'
    $buildRoot = Join-Path $pluginSourceRoot 'build'
    $classesPath = Join-Path $buildRoot 'classes'
    $compileLibPath = Join-Path $buildRoot 'compile-lib'
    $pluginOutputPath = Join-Path $ServerPath 'plugins\mcpserver-core.jar'
    $libraryRoot = Join-Path $ServerPath 'libraries'
    $compileDependencyJars = Get-ChildItem -LiteralPath $libraryRoot -Recurse -Include *.jar -File -ErrorAction SilentlyContinue

    if ($RequiredJavaMajor -lt 21) {
        Write-Warn "The MCPServer welcome plugin is skipped for Minecraft $MinecraftVersion because that version uses an older Java runtime."
        return
    }

    if (-not (Test-Path -LiteralPath (Join-Path $ServerPath 'plugins'))) {
        New-Item -ItemType Directory -Path (Join-Path $ServerPath 'plugins') -Force | Out-Null
    }

    if (-not (Test-Path -LiteralPath $javacPath)) {
        throw 'Java was found, but javac.exe was not available. Please install a full JDK, not a JRE.'
    }

    if (-not (Test-Path -LiteralPath $jarPath)) {
        throw 'Java was found, but jar.exe was not available. Please install a full JDK, not a JRE.'
    }

    if (-not $compileDependencyJars) {
        Write-Warn 'MCPServer custom plugin will be built after the first full server startup, once Paper finishes downloading its libraries.'
        Write-LogLine -Path $LauncherLogPath -Message 'Skipped MCPServer plugin build because Paper libraries are not ready yet.'
        return
    }

    $sourceFiles = Get-ChildItem -LiteralPath $sourcePath -Recurse -Filter *.java -File
    if (-not $sourceFiles) {
        throw "MCPServer plugin source files were not found in $sourcePath"
    }

    $newestSourceWrite = ($sourceFiles | Sort-Object LastWriteTimeUtc -Descending | Select-Object -First 1).LastWriteTimeUtc
    $pluginNeedsBuild = $true

    if (Test-Path -LiteralPath $pluginOutputPath) {
        $pluginWrite = (Get-Item -LiteralPath $pluginOutputPath).LastWriteTimeUtc
        $pluginNeedsBuild = $pluginWrite -lt $newestSourceWrite
    }

    if (-not $pluginNeedsBuild) {
        Write-Success 'MCPServer plugin already built.'
        return
    }

    Write-Info 'Building MCPServer welcome plugin...'
    Write-LogLine -Path $LauncherLogPath -Message 'Building MCPServer plugin.'

    if (Test-Path -LiteralPath $buildRoot) {
        Remove-Item -LiteralPath $buildRoot -Recurse -Force
    }

    New-Item -ItemType Directory -Path $classesPath -Force | Out-Null
    New-Item -ItemType Directory -Path $compileLibPath -Force | Out-Null

    foreach ($dependencyJar in $compileDependencyJars) {
        Copy-Item -LiteralPath $dependencyJar.FullName -Destination (Join-Path $compileLibPath $dependencyJar.Name) -Force
    }

    $javaSourceList = $sourceFiles | ForEach-Object { $_.FullName }
    $compileClassPath = (Join-Path $compileLibPath '*')
    $compileOutput = & $javacPath -cp $compileClassPath -d $classesPath $javaSourceList 2>&1
    if ($LASTEXITCODE -ne 0) {
        $compileText = ($compileOutput | Out-String).Trim()
        Write-LogLine -Path $LauncherLogPath -Message "Plugin compile failed: $compileText"
        throw "MCPServer plugin compile failed. $compileText"
    }

    Copy-Item -LiteralPath (Join-Path $resourcePath 'plugin.yml') -Destination (Join-Path $classesPath 'plugin.yml') -Force

    $jarOutput = & $jarPath --create --file $pluginOutputPath -C $classesPath . 2>&1
    if ($LASTEXITCODE -ne 0) {
        $jarText = ($jarOutput | Out-String).Trim()
        Write-LogLine -Path $LauncherLogPath -Message "Plugin package failed: $jarText"
        throw "MCPServer plugin packaging failed. $jarText"
    }

    Write-Success 'MCPServer welcome plugin built.'
}

function Start-MinecraftServer {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$ServerPath,
        [Parameter(Mandatory)][string]$JavaPath,
        [Parameter(Mandatory)][string]$ServerJarPath,
        [Parameter(Mandatory)][string]$RamChoice,
        [Parameter(Mandatory)][int]$Port,
        [Parameter(Mandatory)][bool]$RestartOnCrash,
        [Parameter(Mandatory)][int]$MaxRestarts,
        [Parameter(Mandatory)][int]$RestartDelaySeconds,
        [Parameter(Mandatory)][string]$LauncherLogPath
    )

    Write-HostJoinGuide -ServerPath $ServerPath

    $runningProcess = Get-RunningServerProcess -ServerPath $ServerPath -ServerJarPath $ServerJarPath
    if ($runningProcess) {
        throw "This Minecraft server is already running in another window. Use localhost on this computer, or run stop.bat before starting it again."
    }

    if (-not (Test-PortAvailable -Port $Port)) {
        throw "Port $Port is already in use. Close the other program using that port, then try again."
    }

    $attempt = 0

    do {
        $attempt++
        $shownClaimLink = $null
        $shownJoinAddress = $null
        Write-Host ''
        Write-LauncherBanner -Title "Starting Server (Attempt $attempt)"
        Write-Info 'The first launch can take a little while because Minecraft creates files.'
        Write-Info 'If tunnel support is enabled, a join address may appear after the server finishes loading.'

        $process = New-Object System.Diagnostics.Process
        $process.StartInfo = New-Object System.Diagnostics.ProcessStartInfo
        $process.StartInfo.FileName = $JavaPath
        $process.StartInfo.WorkingDirectory = $ServerPath
        $process.StartInfo.Arguments = "-Xms$RamChoice -Xmx$RamChoice -jar `"$ServerJarPath`" --nogui"
        $process.StartInfo.UseShellExecute = $false
        $process.StartInfo.RedirectStandardOutput = $true
        $process.StartInfo.RedirectStandardError = $true
        $process.StartInfo.CreateNoWindow = $true

        $outputSubscription = "MCPServer.Output.$attempt"
        $errorSubscription = "MCPServer.Error.$attempt"

        $outputEvent = Register-ObjectEvent -InputObject $process -EventName OutputDataReceived -SourceIdentifier $outputSubscription -Action {
            if ($EventArgs.Data) {
                Write-Host $EventArgs.Data
                Add-Content -LiteralPath $using:LauncherLogPath -Value $EventArgs.Data

                if ($EventArgs.Data -match 'https://playit\.gg/claim/[A-Za-z0-9]+') {
                    Show-TunnelClaimLink -ClaimLink $Matches[0]
                }
                elseif ($EventArgs.Data -match '\b[a-zA-Z0-9.-]+\.(ply\.gg|playit\.gg|playit\.plus)\b') {
                    Show-PublicJoinAddress -ServerPath $using:ServerPath -JoinAddress $Matches[0]
                }
            }
        }

        $errorEvent = Register-ObjectEvent -InputObject $process -EventName ErrorDataReceived -SourceIdentifier $errorSubscription -Action {
            if ($EventArgs.Data) {
                Write-Host $EventArgs.Data -ForegroundColor DarkYellow
                Add-Content -LiteralPath $using:LauncherLogPath -Value $EventArgs.Data

                if ($EventArgs.Data -match 'https://playit\.gg/claim/[A-Za-z0-9]+') {
                    Show-TunnelClaimLink -ClaimLink $Matches[0]
                }
                elseif ($EventArgs.Data -match '\b[a-zA-Z0-9.-]+\.(ply\.gg|playit\.gg|playit\.plus)\b') {
                    Show-PublicJoinAddress -ServerPath $using:ServerPath -JoinAddress $Matches[0]
                }
            }
        }

        $exitCode = $null
        try {
            [void]$process.Start()
            Set-ServerPidFile -ServerPath $ServerPath -ProcessId $process.Id
            $process.BeginOutputReadLine()
            $process.BeginErrorReadLine()
            while (-not $process.WaitForExit(1000)) {
                $tunnelHints = Get-TunnelLogHints -ServerPath $ServerPath
                if ($tunnelHints) {
                    if ($tunnelHints.ClaimLink -and $tunnelHints.ClaimLink -ne $shownClaimLink) {
                        $shownClaimLink = $tunnelHints.ClaimLink
                        Show-TunnelClaimLink -ClaimLink $shownClaimLink
                    }

                    if ($tunnelHints.JoinAddress -and $tunnelHints.JoinAddress -ne $shownJoinAddress) {
                        $shownJoinAddress = $tunnelHints.JoinAddress
                        Show-PublicJoinAddress -ServerPath $ServerPath -JoinAddress $shownJoinAddress
                    }
                }
            }
            $exitCode = $process.ExitCode
        }
        finally {
            Clear-ServerPidFile -ServerPath $ServerPath
            Unregister-Event -SourceIdentifier $outputSubscription -ErrorAction SilentlyContinue
            Unregister-Event -SourceIdentifier $errorSubscription -ErrorAction SilentlyContinue
            $outputEvent | Remove-Job -Force -ErrorAction SilentlyContinue
            $errorEvent | Remove-Job -Force -ErrorAction SilentlyContinue
            $process.Dispose()
        }

        Write-LogLine -Path $LauncherLogPath -Message "Minecraft process exited with code $exitCode"

        if ($exitCode -eq 0) {
            Write-Warn 'The Minecraft server closed normally.'
            break
        }

        if (-not $RestartOnCrash) {
            throw "The Minecraft server stopped unexpectedly with exit code $exitCode."
        }

        if ($attempt -ge $MaxRestarts) {
            throw "The Minecraft server crashed too many times in a row. Last exit code: $exitCode"
        }

        Write-Warn "The server stopped unexpectedly. Restarting in $RestartDelaySeconds seconds..."
        Start-Sleep -Seconds $RestartDelaySeconds
    }
    while ($true)
}

Export-ModuleMember -Function *-*
.FullName }
    $compileClassPath = (Join-Path $compileLibPath '*')
    $compileOutput = & $javacPath --release $RequiredJavaMajor -cp $compileClassPath -d $classesPath $javaSourceList 2>&1
    if ($LASTEXITCODE -ne 0) {
        $compileText = ($compileOutput | Out-String).Trim()
        Write-LogLine -Path $LauncherLogPath -Message "Plugin compile failed: $compileText"
        throw "MCPServer plugin compile failed. $compileText"
    }

    $pluginYamlLines = @(
        'name: MCPServerCore',
        'version: 1.0.0',
        'main: com.mcpserver.core.MCPServerCorePlugin',
        'author: MCPServer',
        'description: MCPServer custom plugin host with DSL and Lua support.'
    )

    if (Test-MinecraftVersionAtLeast -Version $MinecraftVersion -MinimumVersion '1.13') {
        $versionParts = $MinecraftVersion.Split('.')
        $apiVersion = if ($versionParts.Count -ge 2) { "$($versionParts[0]).$($versionParts[1])" } else { $MinecraftVersion }
        $pluginYamlLines += "api-version: '$apiVersion'"
    }

    Set-Content -LiteralPath (Join-Path $classesPath 'plugin.yml') -Encoding ASCII -Value ($pluginYamlLines -join [Environment]::NewLine)

    Push-Location $classesPath
    try {
        foreach ($vendorJar in $vendorJars) {
            $extractOutput = & $jarPath xf $vendorJar.FullName 2>&1
            if ($LASTEXITCODE -ne 0) {
                $extractText = ($extractOutput | Out-String).Trim()
                Write-LogLine -Path $LauncherLogPath -Message "Vendor jar extract failed: $extractText"
                throw "MCPServer vendor jar extract failed. $extractText"
            }
        }
    }
    finally {
        Pop-Location
    }

    $jarOutput = & $jarPath --create --file $pluginOutputPath -C $classesPath . 2>&1
    if ($LASTEXITCODE -ne 0) {
        $jarText = ($jarOutput | Out-String).Trim()
        Write-LogLine -Path $LauncherLogPath -Message "Plugin package failed: $jarText"
        throw "MCPServer plugin packaging failed. $jarText"
    }

    Write-Success 'MCPServer plugin host built.'
}

function Start-MinecraftServer {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$ServerPath,
        [Parameter(Mandatory)][string]$JavaPath,
        [Parameter(Mandatory)][string]$ServerJarPath,
        [Parameter(Mandatory)][string]$RamChoice,
        [Parameter(Mandatory)][int]$Port,
        [Parameter(Mandatory)][bool]$RestartOnCrash,
        [Parameter(Mandatory)][int]$MaxRestarts,
        [Parameter(Mandatory)][int]$RestartDelaySeconds,
        [Parameter(Mandatory)][string]$LauncherLogPath
    )

    Write-HostJoinGuide -ServerPath $ServerPath

    $runningProcess = Get-RunningServerProcess -ServerPath $ServerPath -ServerJarPath $ServerJarPath
    if ($runningProcess) {
        throw "This Minecraft server is already running in another window. Use localhost on this computer, or run stop.bat before starting it again."
    }

    if (-not (Test-PortAvailable -Port $Port)) {
        throw "Port $Port is already in use. Close the other program using that port, then try again."
    }

    $attempt = 0

    do {
        $attempt++
        $shownClaimLink = $null
        $shownJoinAddress = $null
        Write-Host ''
        Write-LauncherBanner -Title "Starting Server (Attempt $attempt)"
        Write-Info 'The first launch can take a little while because Minecraft creates files.'
        Write-Info 'If tunnel support is enabled, a join address may appear after the server finishes loading.'

        $process = New-Object System.Diagnostics.Process
        $process.StartInfo = New-Object System.Diagnostics.ProcessStartInfo
        $process.StartInfo.FileName = $JavaPath
        $process.StartInfo.WorkingDirectory = $ServerPath
        $process.StartInfo.Arguments = "-Xms$RamChoice -Xmx$RamChoice -jar `"$ServerJarPath`" --nogui"
        $process.StartInfo.UseShellExecute = $false
        $process.StartInfo.RedirectStandardOutput = $true
        $process.StartInfo.RedirectStandardError = $true
        $process.StartInfo.CreateNoWindow = $true

        $outputSubscription = "MCPServer.Output.$attempt"
        $errorSubscription = "MCPServer.Error.$attempt"

        $outputEvent = Register-ObjectEvent -InputObject $process -EventName OutputDataReceived -SourceIdentifier $outputSubscription -Action {
            if ($EventArgs.Data) {
                Write-Host $EventArgs.Data
                Add-Content -LiteralPath $using:LauncherLogPath -Value $EventArgs.Data

                if ($EventArgs.Data -match 'https://playit\.gg/claim/[A-Za-z0-9]+') {
                    Show-TunnelClaimLink -ClaimLink $Matches[0]
                }
                elseif ($EventArgs.Data -match '\b[a-zA-Z0-9.-]+\.(ply\.gg|playit\.gg|playit\.plus)\b') {
                    Show-PublicJoinAddress -ServerPath $using:ServerPath -JoinAddress $Matches[0]
                }
            }
        }

        $errorEvent = Register-ObjectEvent -InputObject $process -EventName ErrorDataReceived -SourceIdentifier $errorSubscription -Action {
            if ($EventArgs.Data) {
                Write-Host $EventArgs.Data -ForegroundColor DarkYellow
                Add-Content -LiteralPath $using:LauncherLogPath -Value $EventArgs.Data

                if ($EventArgs.Data -match 'https://playit\.gg/claim/[A-Za-z0-9]+') {
                    Show-TunnelClaimLink -ClaimLink $Matches[0]
                }
                elseif ($EventArgs.Data -match '\b[a-zA-Z0-9.-]+\.(ply\.gg|playit\.gg|playit\.plus)\b') {
                    Show-PublicJoinAddress -ServerPath $using:ServerPath -JoinAddress $Matches[0]
                }
            }
        }

        $exitCode = $null
        try {
            [void]$process.Start()
            Set-ServerPidFile -ServerPath $ServerPath -ProcessId $process.Id
            $process.BeginOutputReadLine()
            $process.BeginErrorReadLine()
            while (-not $process.WaitForExit(1000)) {
                $tunnelHints = Get-TunnelLogHints -ServerPath $ServerPath
                if ($tunnelHints) {
                    if ($tunnelHints.ClaimLink -and $tunnelHints.ClaimLink -ne $shownClaimLink) {
                        $shownClaimLink = $tunnelHints.ClaimLink
                        Show-TunnelClaimLink -ClaimLink $shownClaimLink
                    }

                    if ($tunnelHints.JoinAddress -and $tunnelHints.JoinAddress -ne $shownJoinAddress) {
                        $shownJoinAddress = $tunnelHints.JoinAddress
                        Show-PublicJoinAddress -ServerPath $ServerPath -JoinAddress $shownJoinAddress
                    }
                }
            }
            $exitCode = $process.ExitCode
        }
        finally {
            Clear-ServerPidFile -ServerPath $ServerPath
            Unregister-Event -SourceIdentifier $outputSubscription -ErrorAction SilentlyContinue
            Unregister-Event -SourceIdentifier $errorSubscription -ErrorAction SilentlyContinue
            $outputEvent | Remove-Job -Force -ErrorAction SilentlyContinue
            $errorEvent | Remove-Job -Force -ErrorAction SilentlyContinue
            $process.Dispose()
        }

        Write-LogLine -Path $LauncherLogPath -Message "Minecraft process exited with code $exitCode"

        if ($exitCode -eq 0) {
            Write-Warn 'The Minecraft server closed normally.'
            break
        }

        if (-not $RestartOnCrash) {
            throw "The Minecraft server stopped unexpectedly with exit code $exitCode."
        }

        if ($attempt -ge $MaxRestarts) {
            throw "The Minecraft server crashed too many times in a row. Last exit code: $exitCode"
        }

        Write-Warn "The server stopped unexpectedly. Restarting in $RestartDelaySeconds seconds..."
        Start-Sleep -Seconds $RestartDelaySeconds
    }
    while ($true)
}

Export-ModuleMember -Function *-*

