Set-StrictMode -Version Latest

function Initialize-McpServerFolders {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$RootPath
    )

    $folders = @(
        'server',
        'server\instances',
        'server\plugins',
        'tunnel',
        'config',
        'logs'
    )

    foreach ($folder in $folders) {
        $path = Join-Path $RootPath $folder
        if (-not (Test-Path -LiteralPath $path)) {
            New-Item -ItemType Directory -Path $path | Out-Null
        }
    }
}

function New-LauncherLog {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$RootPath
    )

    $timestamp = Get-Date -Format 'yyyy-MM-dd_HH-mm-ss'
    $path = Join-Path $RootPath ("logs\launcher-$timestamp.log")
    New-Item -ItemType File -Path $path -Force | Out-Null
    return $path
}

function Write-LogLine {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$Path,
        [Parameter(Mandatory)]
        [string]$Message
    )

    Add-Content -LiteralPath $Path -Value ("[{0}] {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Message)
}

function Write-LauncherBanner {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$Title
    )

    Write-Host '============================================================' -ForegroundColor Cyan
    Write-Host $Title -ForegroundColor Cyan
    Write-Host '============================================================' -ForegroundColor Cyan
}

function Write-Info {
    [CmdletBinding()]
    param([Parameter(Mandatory)][string]$Message)

    Write-Host "[INFO] $Message" -ForegroundColor Gray
}

function Write-Success {
    [CmdletBinding()]
    param([Parameter(Mandatory)][string]$Message)

    Write-Host "[OK]   $Message" -ForegroundColor Green
}

function Write-Warn {
    [CmdletBinding()]
    param([Parameter(Mandatory)][string]$Message)

    Write-Host "[WARN] $Message" -ForegroundColor Yellow
}

function Write-FriendlyError {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [System.Management.Automation.ErrorRecord]$ErrorRecord
    )

    Write-Host ''
    Write-Host 'Something needs attention before the server can continue:' -ForegroundColor Red
    Write-Host $ErrorRecord.Exception.Message -ForegroundColor Red
    Write-Host ''
    Write-Host 'Helpful next step:' -ForegroundColor Yellow

    if ($ErrorRecord.Exception.Message -match 'Java') {
        Write-Host 'Install the Java version requested in the error message, then run start.bat again.' -ForegroundColor Yellow
        Write-Host 'Recommended download: https://adoptium.net/' -ForegroundColor Yellow
    }
    else {
        Write-Host 'Read the newest file inside the logs folder for more details.' -ForegroundColor Yellow
    }
}

function Get-McpSettings {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$RootPath
    )

    $settingsPath = Join-Path $RootPath 'config\settings.json'
    if (-not (Test-Path -LiteralPath $settingsPath)) {
        throw "Missing settings file: $settingsPath"
    }

    return Get-Content -LiteralPath $settingsPath -Raw | ConvertFrom-Json
}

function Select-RamSetting {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$DefaultRam
    )

    Write-Host 'Choose how much RAM to give the server.' -ForegroundColor Cyan
    Write-Host 'More RAM can help larger worlds and more players.' -ForegroundColor Gray
    Write-Host ''
    Write-Host '1. 2 GB'
    Write-Host '2. 4 GB'
    Write-Host '3. 6 GB'
    Write-Host '4. 8 GB'
    Write-Host '5. Custom amount'
    Write-Host ''

    $selection = Read-Host "Press Enter for the default ($DefaultRam), or choose 1-5"

    switch ($selection) {
        '' { return $DefaultRam }
        '1' { return '2G' }
        '2' { return '4G' }
        '3' { return '6G' }
        '4' { return '8G' }
        '5' {
            $custom = Read-Host 'Type a RAM value like 3G or 6144M'
            if ($custom -notmatch '^\d+(G|M)$') {
                throw 'RAM must look like 2G, 4G, 6G, or 6144M.'
            }

            return $custom.ToUpperInvariant()
        }
        default {
            throw 'Please choose a number from 1 to 5.'
        }
    }
}

function Get-VersionParts {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$Version
    )

    $match = [regex]::Match($Version, '^(?<major>\d+)\.(?<minor>\d+)(?:\.(?<patch>\d+))?$')
    if (-not $match.Success) {
        throw "Minecraft version '$Version' is not in a supported format."
    }

    return [pscustomobject]@{
        Major = [int]$match.Groups['major'].Value
        Minor = [int]$match.Groups['minor'].Value
        Patch = if ($match.Groups['patch'].Success) { [int]$match.Groups['patch'].Value } else { 0 }
    }
}

function Test-MinecraftVersionAtLeast {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Version,
        [Parameter(Mandatory)][string]$MinimumVersion
    )

    $left = Get-VersionParts -Version $Version
    $right = Get-VersionParts -Version $MinimumVersion

    foreach ($part in 'Major', 'Minor', 'Patch') {
        if ($left.$part -gt $right.$part) { return $true }
        if ($left.$part -lt $right.$part) { return $false }
    }

    return $true
}

function Get-RequiredJavaMajorForMinecraftVersion {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$MinecraftVersion
    )

    if (-not (Test-MinecraftVersionAtLeast -Version $MinecraftVersion -MinimumVersion '1.12.2')) {
        throw 'MCPServer currently supports Minecraft 1.12.2 and newer.'
    }

    if (Test-MinecraftVersionAtLeast -Version $MinecraftVersion -MinimumVersion '1.17.1') {
        return 21
    }

    if ($MinecraftVersion -eq '1.16.5') {
        return 16
    }

    return 11
}

function Select-MinecraftVersion {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string[]]$SupportedVersions,
        [Parameter(Mandatory)]
        [string]$DefaultVersion
    )

    Write-Host 'Choose the Minecraft server version.' -ForegroundColor Cyan
    Write-Host 'Different versions may need different Java versions.' -ForegroundColor Gray
    Write-Host ''

    for ($i = 0; $i -lt $SupportedVersions.Count; $i++) {
        Write-Host ("{0}. {1}" -f ($i + 1), $SupportedVersions[$i])
    }

    $customIndex = $SupportedVersions.Count + 1
    Write-Host ("{0}. Custom version" -f $customIndex)
    Write-Host ''

    $selection = Read-Host "Press Enter for the default ($DefaultVersion), or choose 1-$customIndex"

    if ([string]::IsNullOrWhiteSpace($selection)) {
        return $DefaultVersion
    }

    if ($selection -match '^\d+$') {
        $selectionNumber = [int]$selection
        if ($selectionNumber -ge 1 -and $selectionNumber -le $SupportedVersions.Count) {
            return $SupportedVersions[$selectionNumber - 1]
        }

        if ($selectionNumber -eq $customIndex) {
            $customVersion = Read-Host 'Type a version like 1.12.2, 1.16.5, or 1.21.8'
            [void](Get-RequiredJavaMajorForMinecraftVersion -MinecraftVersion $customVersion)
            return $customVersion
        }
    }

    throw "Please choose a number from 1 to $customIndex."
}

function Get-ServerInstancePath {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$RootPath,
        [Parameter(Mandatory)][string]$MinecraftVersion,
        [Parameter(Mandatory)][string]$DefaultMinecraftVersion
    )

    $legacyServerPath = Join-Path $RootPath 'server'
    $legacyServerJarPath = Join-Path $legacyServerPath 'paper.jar'

    if ($MinecraftVersion -eq $DefaultMinecraftVersion -and (Test-Path -LiteralPath $legacyServerJarPath)) {
        return $legacyServerPath
    }

    return (Join-Path $RootPath ("server\instances\$MinecraftVersion"))
}

function Get-JavaInfo {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [int]$MinimumMajorVersion
    )

    $candidates = New-Object System.Collections.Generic.List[string]

    if ($env:JAVA_HOME) {
        $candidates.Add((Join-Path $env:JAVA_HOME 'bin\java.exe'))
    }

    $javaCommand = Get-Command java -ErrorAction SilentlyContinue
    if ($javaCommand) {
        $candidates.Add($javaCommand.Source)
    }

    $javaPath = $candidates |
        Where-Object { $_ -and (Test-Path -LiteralPath $_) } |
        Select-Object -First 1

    if (-not $javaPath) {
        throw "Java $MinimumMajorVersion or newer was not found on this computer."
    }

    $versionOutputText = & cmd.exe /d /c "`"$javaPath`" -version 2>&1"
    if (-not $versionOutputText) {
        throw 'Java was found, but its version could not be read.'
    }

    $versionLine = ($versionOutputText | Select-Object -First 1).ToString()
    $majorVersion = $null

    if ($versionLine -match '"(?<version>\d+)(\.\d+)?') {
        $majorVersion = [int]$Matches.version
    }

    if (-not $majorVersion) {
        throw 'Java was found, but the version number could not be understood.'
    }

    if ($majorVersion -lt $MinimumMajorVersion) {
        throw "Java $MinimumMajorVersion or newer is required. Current version: $versionLine"
    }

    [pscustomobject]@{
        Path        = $javaPath
        VersionText = $versionLine
        Major       = $majorVersion
    }
}

function Show-StartupSummary {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$MinecraftVersion,
        [Parameter(Mandatory)][string]$RamChoice,
        [Parameter(Mandatory)]$TunnelStatus,
        [Parameter(Mandatory)][int]$RequiredJavaMajor,
        [Parameter(Mandatory)][string]$ServerPath
    )

    Write-Host ''
    Write-LauncherBanner -Title 'Ready To Launch'
    Write-Info "Minecraft version: $MinecraftVersion"
    Write-Info "Server folder: $ServerPath"
    Write-Info "RAM: $RamChoice"
    Write-Info "Required Java: $RequiredJavaMajor+"
    Write-Info 'Host computer join address: localhost'
    if ($TunnelStatus.Enabled) {
        Write-Info "Tunnel helper: $($TunnelStatus.ProviderName)"
        Write-Info 'Friends outside your network should use the public Playit address.'
    }
    else {
        Write-Warn 'Tunnel helper: disabled'
    }
    Write-Host ''
}

Export-ModuleMember -Function *-*
