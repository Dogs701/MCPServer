function onServerStart(api, event)
    api:log('hello-world plugin saw server.start')
end

function onPlayerJoin(api, event)
    local playerName = event:get('player')
    api:reply('&aWelcome from Lua, ' .. playerName .. '!')
end

function onHello(api, event)
    local sender = event:get('sender')
    api:reply('&bHello from MCP Lua, ' .. sender .. '!')
end
