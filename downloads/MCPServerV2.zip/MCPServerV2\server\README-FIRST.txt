This folder starts empty in the public package on purpose.
MCPServer will download and create the server files automatically on first launch.

Do not place your personal world files in the public release package.
