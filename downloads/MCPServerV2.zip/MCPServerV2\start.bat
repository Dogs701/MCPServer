@echo off
setlocal

set "ROOT=%~dp0"
cd /d "%ROOT%"

echo ============================================================
echo MCPServer
echo Beginner-friendly Minecraft server launcher
echo ============================================================
echo.

powershell -NoProfile -ExecutionPolicy Bypass -File "%ROOT%setup.ps1" -Action Start
set "EXIT_CODE=%ERRORLEVEL%"

if not "%EXIT_CODE%"=="0" (
    echo.
    echo MCPServer closed with an error code: %EXIT_CODE%
)

echo.
pause
exit /b %EXIT_CODE%
