[CmdletBinding()]
param(
    [ValidateSet('Start', 'Stop')]
    [string]$Action = 'Start'
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$RootPath = Split-Path -Parent $MyInvocation.MyCommand.Path

Import-Module (Join-Path $RootPath 'scripts\Common.psm1') -Force
Import-Module (Join-Path $RootPath 'scripts\ServerManager.psm1') -Force
Import-Module (Join-Path $RootPath 'scripts\TunnelManager.psm1') -Force

Initialize-McpServerFolders -RootPath $RootPath
$launcherLog = New-LauncherLog -RootPath $RootPath
$settings = Get-McpSettings -RootPath $RootPath
$defaultMinecraftVersion = if ($settings.defaultMinecraftVersion) { $settings.defaultMinecraftVersion } else { $settings.minecraftVersion }
$supportedMinecraftVersions = if ($settings.supportedMinecraftVersions) { @($settings.supportedMinecraftVersions) } else { @($defaultMinecraftVersion) }

if ($Action -eq 'Stop') {
    try {
        Write-LauncherBanner -Title 'MCPServer Stop'
        Stop-McpServerProcesses -RootPath $RootPath -LauncherLogPath $launcherLog
        exit 0
    }
    catch {
        Write-FriendlyError -ErrorRecord $_
        Write-LogLine -Path $launcherLog -Message ("ERROR: " + $_.Exception.Message)
        exit 1
    }
}

Write-LauncherBanner -Title 'MCPServer Setup'
Write-Info "Everything in this folder stays local on your computer."
Write-Info "No router changes or port forwarding are needed."
Write-Info "Default Minecraft version: $defaultMinecraftVersion"
Write-Info "Default server port: $($settings.serverPort)"
Write-Host ''

try {
    $minecraftVersion = Select-MinecraftVersion `
        -SupportedVersions $supportedMinecraftVersions `
        -DefaultVersion $defaultMinecraftVersion
    $requiredJavaMajor = Get-RequiredJavaMajorForMinecraftVersion -MinecraftVersion $minecraftVersion
    $serverPath = Get-ServerInstancePath `
        -RootPath $RootPath `
        -MinecraftVersion $minecraftVersion `
        -DefaultMinecraftVersion $defaultMinecraftVersion

    $ramChoice = Select-RamSetting -DefaultRam $settings.defaultRam
    $javaInfo = Get-JavaInfo -MinimumMajorVersion $requiredJavaMajor
    Write-Success "Java found: $($javaInfo.Path)"
    Write-Info "Java version: $($javaInfo.VersionText)"

    $paperInfo = Ensure-PaperServer `
        -RootPath $RootPath `
        -ServerPath $serverPath `
        -MinecraftVersion $minecraftVersion `
        -PaperProject $settings.paperProject `
        -LauncherLogPath $launcherLog

    Initialize-ServerFiles `
        -ServerPath $serverPath `
        -ServerJarPath $paperInfo.ServerJarPath `
        -MinecraftVersion $paperInfo.MinecraftVersion `
        -LauncherLogPath $launcherLog

    $tunnelStatus = Ensure-TunnelProvider `
        -RootPath $RootPath `
        -ServerPath $serverPath `
        -MinecraftVersion $paperInfo.MinecraftVersion `
        -Enabled:$settings.enableTunnel `
        -LauncherLogPath $launcherLog

    Ensure-McpServerPlugin `
        -RootPath $RootPath `
        -ServerPath $serverPath `
        -MinecraftVersion $paperInfo.MinecraftVersion `
        -RequiredJavaMajor $requiredJavaMajor `
        -JavaPath $javaInfo.Path `
        -ServerJarPath $paperInfo.ServerJarPath `
        -LauncherLogPath $launcherLog

    Show-StartupSummary `
        -MinecraftVersion $paperInfo.MinecraftVersion `
        -RamChoice $ramChoice `
        -TunnelStatus $tunnelStatus `
        -RequiredJavaMajor $requiredJavaMajor `
        -ServerPath $serverPath

    Start-MinecraftServer `
        -ServerPath $serverPath `
        -JavaPath $javaInfo.Path `
        -ServerJarPath $paperInfo.ServerJarPath `
        -RamChoice $ramChoice `
        -Port $settings.serverPort `
        -RestartOnCrash:$settings.restartOnCrash `
        -MaxRestarts $settings.maxRestarts `
        -RestartDelaySeconds $settings.restartDelaySeconds `
        -LauncherLogPath $launcherLog
}
catch {
    Write-FriendlyError -ErrorRecord $_
    Write-LogLine -Path $launcherLog -Message ("ERROR: " + $_.Exception.Message)
    exit 1
}
