package com.mcpserver.core.mcp.api;

import com.mcpserver.core.MCPServerCorePlugin;
import org.bukkit.Bukkit;

public final class BukkitPluginApi implements PluginApi {
    private final MCPServerCorePlugin plugin;

    public BukkitPluginApi(MCPServerCorePlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public void log(String message) {
        plugin.getLogger().info("[MCPPlugin] " + message);
    }

    @Override
    public void reply(String message) {
        Bukkit.broadcastMessage(colorize("&6&lMCPPlugin &8> &f" + message));
    }

    @Override
    public String colorize(String message) {
        return plugin.colorize(message);
    }
}
