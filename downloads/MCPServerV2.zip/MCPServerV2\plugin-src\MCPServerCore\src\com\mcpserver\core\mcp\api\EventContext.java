package com.mcpserver.core.mcp.api;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

public final class EventContext {
    private final String name;
    private final Map<String, Object> data;

    public EventContext(String name, Map<String, Object> data) {
        this.name = name;
        this.data = Collections.unmodifiableMap(new LinkedHashMap<>(data));
    }

    public String getName() {
        return name;
    }

    public Object get(String key) {
        return data.get(key);
    }

    public Map<String, Object> getData() {
        return data;
    }
}
