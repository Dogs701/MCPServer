package com.mcpserver.core.mcp.runtime;

import com.mcpserver.core.mcp.api.EventContext;
import com.mcpserver.core.mcp.api.PluginApi;
import com.mcpserver.core.mcp.dsl.PluginDescriptor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.file.Files;

public final class LuaRuntimeBridge {
    private static final String GLOBALS_CLASS = "org.luaj.vm2.Globals";
    private static final String JSE_PLATFORM_CLASS = "org.luaj.vm2.lib.jse.JsePlatform";
    private static final String LUA_VALUE_CLASS = "org.luaj.vm2.LuaValue";
    private static final String COERCE_CLASS = "org.luaj.vm2.lib.jse.CoerceJavaToLua";

    public boolean isAvailable() {
        try {
            Class.forName(JSE_PLATFORM_CLASS);
            return true;
        } catch (ClassNotFoundException ex) {
            return false;
        }
    }

    public void invoke(PluginDescriptor descriptor, String functionName, PluginApi api, EventContext event) {
        if (!isAvailable()) {
            api.log("LuaJ not found; skipped Lua handler '" + functionName + "' for plugin " + descriptor.getId());
            return;
        }

        try {
            if (!Files.exists(descriptor.getMainScript())) {
                api.log("Lua script missing: " + descriptor.getMainScript());
                return;
            }

            Class<?> jsePlatform = Class.forName(JSE_PLATFORM_CLASS);
            Class<?> globalsClass = Class.forName(GLOBALS_CLASS);
            Class<?> luaValueClass = Class.forName(LUA_VALUE_CLASS);
            Class<?> coerceClass = Class.forName(COERCE_CLASS);

            Method standardGlobals = jsePlatform.getMethod("standardGlobals");
            Object globals = standardGlobals.invoke(null);

            Method loadfile = globalsClass.getMethod("loadfile", String.class);
            Object chunk = loadfile.invoke(globals, descriptor.getMainScript().toString());

            Method callNoArgs = luaValueClass.getMethod("call");
            callNoArgs.invoke(chunk);

            Method get = globalsClass.getMethod("get", String.class);
            Object function = get.invoke(globals, functionName);

            Method isNil = luaValueClass.getMethod("isnil");
            boolean missingFunction = function == null || Boolean.TRUE.equals(isNil.invoke(function));
            if (missingFunction) {
                api.log("Lua function not found: " + functionName);
                return;
            }

            Method coerce = coerceClass.getMethod("coerce", Object.class);
            Object luaApi = coerce.invoke(null, api);
            Object luaEvent = coerce.invoke(null, event);

            Method callTwoArgs = luaValueClass.getMethod("call", luaValueClass, luaValueClass);
            callTwoArgs.invoke(function, luaApi, luaEvent);
        } catch (ClassNotFoundException | NoSuchMethodException | IllegalAccessException ex) {
            throw new IllegalStateException("Lua bridge reflection failed", ex);
        } catch (InvocationTargetException ex) {
            throw new IllegalStateException("Lua function threw an error", ex.getTargetException());
        }
    }
}
