package com.mcpserver.core.mcp.runtime;

import com.mcpserver.core.mcp.dsl.PluginDescriptor;

public final class LoadedPlugin {
    private final PluginDescriptor descriptor;

    public LoadedPlugin(PluginDescriptor descriptor) {
        this.descriptor = descriptor;
    }

    public PluginDescriptor descriptor() {
        return descriptor;
    }
}
