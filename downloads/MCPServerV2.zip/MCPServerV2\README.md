# MCPServer

MCPServer is a beginner-friendly local Minecraft server launcher for Windows.

## What it does

- Detects Java automatically and checks that it is new enough.
- Downloads a Paper server automatically on first launch.
- Accepts the Minecraft EULA automatically.
- Lets the user choose RAM in a simple command-line menu.
- Starts the server with beginner-friendly console messages.
- Installs a tunnel helper so the server can be shared without port forwarding.
- Restarts the server automatically if it crashes.

## How to use it

1. Download the folder.
2. Double-click `start.bat`.
3. Pick a RAM amount.
4. Wait for the server to finish loading.
5. If a claim link appears, open it once.
6. Share the public join address shown in the console.

## Notes

- This package currently targets Paper for Minecraft `1.21.8`.
- Modern Paper builds require Java 21.
- The tunnel helper may ask for a one-time browser claim on the first run.
- If something goes wrong, check the newest file in the `logs` folder.
