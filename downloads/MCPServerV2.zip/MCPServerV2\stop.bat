@echo off
setlocal

set "ROOT=%~dp0"
cd /d "%ROOT%"

echo ============================================================
echo MCPServer Stop
echo Stop any running MCPServer Java server from this folder
echo ============================================================
echo.

powershell -NoProfile -ExecutionPolicy Bypass -File "%ROOT%setup.ps1" -Action Stop
set "EXIT_CODE=%ERRORLEVEL%"

echo.
pause
exit /b %EXIT_CODE%
