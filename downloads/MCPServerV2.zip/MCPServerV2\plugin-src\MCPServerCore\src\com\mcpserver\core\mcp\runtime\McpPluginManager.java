package com.mcpserver.core.mcp.runtime;

import com.mcpserver.core.MCPServerCorePlugin;
import com.mcpserver.core.mcp.api.BukkitPluginApi;
import com.mcpserver.core.mcp.api.EventContext;
import com.mcpserver.core.mcp.dsl.PluginDescriptor;
import com.mcpserver.core.mcp.dsl.PluginDslParser;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.stream.Stream;
import org.bukkit.Bukkit;

public final class McpPluginManager {
    private final MCPServerCorePlugin host;
    private final File pluginRoot;
    private final PluginDslParser parser = new PluginDslParser();
    private final LuaRuntimeBridge lua = new LuaRuntimeBridge();
    private final List<LoadedPlugin> plugins = new ArrayList<>();

    public McpPluginManager(MCPServerCorePlugin host, File pluginRoot) {
        this.host = host;
        this.pluginRoot = pluginRoot;
    }

    public void loadPlugins() throws IOException {
        clear();
        if (!pluginRoot.exists() && !pluginRoot.mkdirs()) {
            throw new IOException("Could not create MCP plugins folder at " + pluginRoot);
        }

        writeExamplePluginIfMissing();

        try (Stream<Path> paths = Files.walk(pluginRoot.toPath(), 2)) {
            paths.filter(path -> path.getFileName().toString().equals("plugin.mcp"))
                    .forEach(this::loadPlugin);
        }

        host.getLogger().info("Loaded " + plugins.size() + " MCP plugin(s) from " + pluginRoot.getAbsolutePath());
        BukkitPluginApi api = host.createPluginApi();
        emit("server.start", Map.of("pluginCount", plugins.size()), api);
    }

    public void clear() {
        plugins.clear();
    }

    public void emit(String eventName, Map<String, Object> data) {
        emit(eventName, data, host.createPluginApi());
    }

    public boolean dispatchCommand(String commandName, Map<String, Object> data) {
        BukkitPluginApi api = host.createPluginApi();
        EventContext event = new EventContext("command." + commandName, data);
        boolean handled = false;

        for (LoadedPlugin plugin : plugins) {
            String functionName = plugin.descriptor().getCommands().get(commandName);
            if (functionName != null) {
                handled = true;
                invoke(plugin.descriptor(), functionName, api, event);
            }
        }

        return handled;
    }

    private void emit(String eventName, Map<String, Object> data, BukkitPluginApi api) {
        EventContext event = new EventContext(eventName, data);
        for (LoadedPlugin plugin : plugins) {
            String functionName = plugin.descriptor().getEvents().get(eventName);
            if (functionName != null) {
                invoke(plugin.descriptor(), functionName, api, event);
            }
        }
    }

    private void invoke(PluginDescriptor descriptor, String functionName, BukkitPluginApi api, EventContext event) {
        try {
            lua.invoke(descriptor, functionName, api, event);
        } catch (Exception ex) {
            host.getLogger().log(Level.SEVERE, "MCP plugin '" + descriptor.getId() + "' failed in handler '" + functionName + "'", ex);
        }
    }

    private void loadPlugin(Path descriptorPath) {
        try {
            PluginDescriptor descriptor = parser.parse(descriptorPath);
            plugins.add(new LoadedPlugin(descriptor));
            host.getLogger().info("Loaded MCP plugin " + descriptor.getId() + " v" + descriptor.getVersion());
        } catch (Exception ex) {
            host.getLogger().log(Level.SEVERE, "Failed to load MCP plugin at " + descriptorPath, ex);
        }
    }

    private void writeExamplePluginIfMissing() throws IOException {
        Path exampleDir = pluginRoot.toPath().resolve("hello-world");
        Path descriptor = exampleDir.resolve("plugin.mcp");
        Path script = exampleDir.resolve("plugin.lua");

        if (Files.exists(descriptor) || Files.exists(script)) {
            return;
        }

        Files.createDirectories(exampleDir);
        Files.writeString(descriptor, String.join(System.lineSeparator(),
                "plugin \"hello-world\"",
                "version \"1.0.0\"",
                "main \"plugin.lua\"",
                "",
                "command \"hello\" -> \"onHello\"",
                "event \"server.start\" -> \"onServerStart\"",
                "event \"player.join\" -> \"onPlayerJoin\"",
                ""));
        Files.writeString(script, String.join(System.lineSeparator(),
                "function onServerStart(api, event)",
                "    api:log('hello-world plugin saw server.start')",
                "end",
                "",
                "function onPlayerJoin(api, event)",
                "    local playerName = event:get('player')",
                "    api:reply('&aWelcome from Lua, ' .. playerName .. '!')",
                "end",
                "",
                "function onHello(api, event)",
                "    local sender = event:get('sender')",
                "    api:reply('&bHello from MCP Lua, ' .. sender .. '!')",
                "end",
                ""));
    }
}
