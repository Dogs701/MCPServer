package com.mcpserver.core.mcp.api;

public interface PluginApi {
    void log(String message);
    void reply(String message);
    String colorize(String message);
}
