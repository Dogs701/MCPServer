package com.mcpserver.core.mcp.dsl;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class PluginDslParser {
    public PluginDescriptor parse(Path descriptorPath) throws IOException {
        List<String> lines = Files.readAllLines(descriptorPath);
        String id = null;
        String version = null;
        String main = null;
        Map<String, String> commands = new LinkedHashMap<>();
        Map<String, String> events = new LinkedHashMap<>();

        for (int i = 0; i < lines.size(); i++) {
            String rawLine = lines.get(i);
            String line = stripComment(rawLine).trim();
            if (line.isEmpty()) {
                continue;
            }

            if (line.startsWith("plugin ")) {
                id = parseQuotedValue(line, "plugin", i);
                continue;
            }

            if (line.startsWith("version ")) {
                version = parseQuotedValue(line, "version", i);
                continue;
            }

            if (line.startsWith("main ")) {
                main = parseQuotedValue(line, "main", i);
                continue;
            }

            if (line.startsWith("command ")) {
                String[] mapping = parseMapping(line, "command", i);
                commands.put(mapping[0], mapping[1]);
                continue;
            }

            if (line.startsWith("event ")) {
                String[] mapping = parseMapping(line, "event", i);
                events.put(mapping[0], mapping[1]);
                continue;
            }

            throw new IllegalArgumentException("Unknown DSL statement at line " + (i + 1) + ": " + rawLine);
        }

        if (id == null || id.isBlank()) {
            throw new IllegalArgumentException("Plugin id is required");
        }
        if (version == null || version.isBlank()) {
            throw new IllegalArgumentException("Plugin version is required");
        }
        if (main == null || main.isBlank()) {
            throw new IllegalArgumentException("Plugin main script is required");
        }

        Path directory = descriptorPath.getParent();
        Path mainScript = directory.resolve(main).normalize();
        return new PluginDescriptor(id, version, directory, mainScript, commands, events);
    }

    private String stripComment(String line) {
        int commentIndex = line.indexOf('#');
        if (commentIndex >= 0) {
            return line.substring(0, commentIndex);
        }
        return line;
    }

    private String parseQuotedValue(String line, String keyword, int lineIndex) {
        String tail = line.substring(keyword.length()).trim();
        return unquote(tail, lineIndex);
    }

    private String[] parseMapping(String line, String keyword, int lineIndex) {
        String tail = line.substring(keyword.length()).trim();
        int arrowIndex = tail.indexOf("->");
        if (arrowIndex < 0) {
            throw new IllegalArgumentException("Expected '->' in " + keyword + " statement at line " + (lineIndex + 1));
        }

        String left = tail.substring(0, arrowIndex).trim();
        String right = tail.substring(arrowIndex + 2).trim();
        return new String[] {unquote(left, lineIndex), unquote(right, lineIndex)};
    }

    private String unquote(String value, int lineIndex) {
        if (value.length() >= 2 && value.startsWith("\"") && value.endsWith("\"")) {
            return value.substring(1, value.length() - 1);
        }
        throw new IllegalArgumentException("Expected quoted string at line " + (lineIndex + 1) + ": " + value);
    }
}
