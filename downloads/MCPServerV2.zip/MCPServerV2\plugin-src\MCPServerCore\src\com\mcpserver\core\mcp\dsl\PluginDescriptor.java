package com.mcpserver.core.mcp.dsl;

import java.nio.file.Path;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

public final class PluginDescriptor {
    private final String id;
    private final String version;
    private final Path directory;
    private final Path mainScript;
    private final Map<String, String> commands;
    private final Map<String, String> events;

    public PluginDescriptor(
            String id,
            String version,
            Path directory,
            Path mainScript,
            Map<String, String> commands,
            Map<String, String> events) {
        this.id = id;
        this.version = version;
        this.directory = directory;
        this.mainScript = mainScript;
        this.commands = Collections.unmodifiableMap(new LinkedHashMap<>(commands));
        this.events = Collections.unmodifiableMap(new LinkedHashMap<>(events));
    }

    public String getId() {
        return id;
    }

    public String getVersion() {
        return version;
    }

    public Path getDirectory() {
        return directory;
    }

    public Path getMainScript() {
        return mainScript;
    }

    public Map<String, String> getCommands() {
        return commands;
    }

    public Map<String, String> getEvents() {
        return events;
    }
}
