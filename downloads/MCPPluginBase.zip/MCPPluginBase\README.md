# MCP Plugin Base

This is a starter MCP plugin for `MCPServer`.

## Files

- `plugin.mcp` - plugin metadata and DSL bindings
- `plugin.lua` - Lua behavior

## How to use

1. Rename the folder to your plugin name.
2. Edit `plugin.mcp`.
3. Edit `plugin.lua`.
4. Drop the folder into `server/plugins/MCPPlugins`.
5. Restart the server.

## Example

Command:

```text
/starter
```

If your plugin is loaded, it should send a chat reply.
