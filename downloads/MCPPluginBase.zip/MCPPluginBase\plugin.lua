function onServerStart(api, event)
    api:log("my-first-plugin loaded successfully")
end

function onPlayerJoin(api, event)
    local playerName = event:get("player")
    api:reply("&aWelcome " .. playerName .. " from my-first-plugin!")
end

function onStarter(api, event)
    local sender = event:get("sender")
    api:reply("&bStarter command worked for " .. sender .. "!")
end
